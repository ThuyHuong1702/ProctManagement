<?php

namespace Modules\Variation\Http\Controllers\Admin;

use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Variation\Entities\Variation;

class VariationController
{
    /**
     * Hiển thị danh sách dữ liệu.
     *
     * @return View
     */
    public function index(Request $request)
    {
        // Danh sách cột có thể sắp xếp
        $sortableColumns = ['id', 'name', 'price', 'in_stock', 'updated_at'];

        // Lấy giá trị cột cần sắp xếp từ request, mặc định là 'id'
        $sortBy = $request->get('sort_by', 'id');

        // Kiểm tra nếu cột không hợp lệ, đặt lại thành 'id'
        if (!in_array($sortBy, $sortableColumns)) {
            $sortBy = 'id';
        }

        // Lấy thứ tự sắp xếp, mặc định là 'asc'
        $sortOrder = $request->get('sort', 'asc');
        if (!in_array(strtolower($sortOrder), ['asc', 'desc'])) {
            $sortOrder = 'asc';
        }

        $perPage = $request->input('per_page', 2);
        $totalProducts = Variation::count(); // Tổng số sản phẩm

        // Sử dụng paginate thay vì all hoặc get
        $variations = Variation::orderBy($sortBy, $sortOrder)->paginate($perPage);

        return view('variation::admin.variations.index', compact('variations', 'perPage', 'totalProducts')); // Trả về view cùng dữ liệu
    }


    /**
     * Hiển thị form thêm dữ liệu mới.
     *
     * @return View
     */
    public function create()
    {
        return view('variation::admin.variations.create'); // Hiển thị form thêm
    }

    /**
     * Lưu dữ liệu mới vào cơ sở dữ liệu.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        // Xác thực dữ liệu
        $request->validate([
            'name' => 'required|string|max:255',
            'type' => 'required|string|max:255',
        ]);

        // Tạo bản ghi mới
        Variation::create([
            'name' => $request->name,
            'type' => $request->type,
        ]);

        // Chuyển hướng về danh sách với thông báo
        return redirect()->route('admin.variations.index')->with('success', 'Dữ liệu đã được thêm thành công!');
    }

    /**
     * Hiển thị chi tiết dữ liệu (nếu cần).
     *
     * @param int $id
     * @return View
     */
    public function show($id)
    {
        $variation = Variation::findOrFail($id); // Lấy dữ liệu theo ID
        return view('variation::admin.variations.show', compact('variation')); // Trả về view hiển thị chi tiết
    }

    /**
     * Hiển thị form sửa dữ liệu.
     *
     * @param int $id
     * @return View
     */
    public function edit($id)
    {
        $variation = Variation::findOrFail($id); // Lấy dữ liệu theo ID
        return view('variation::admin.variations.edit', compact('variation')); // Trả về form chỉnh sửa
    }

    /**
     * Cập nhật dữ liệu vào cơ sở dữ liệu.
     *
     * @param Request $request
     * @param int $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        // Xác thực dữ liệu
        $request->validate([
            'name' => 'required|string|max:255',
            'type' => 'required|string|max:255',
        ]);

        // Tìm và cập nhật bản ghi
        $variation = Variation::findOrFail($id);
        $variation->update([
            'name' => $request->name,
            'type' => $request->type,
        ]);

        // Chuyển hướng về danh sách với thông báo
        return redirect()->route('admin.variations.index')->with('success', 'Dữ liệu đã được cập nhật thành công!');
    }

    /**
     * Xóa bản ghi khỏi cơ sở dữ liệu.
     *
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $variation = Variation::findOrFail($id); // Lấy dữ liệu theo ID
        $variation->delete();

        // Chuyển hướng về danh sách với thông báo
        return redirect()->route('admin.variations.index')->with('success', 'Dữ liệu đã được xóa thành công!');
    }
    public function bulkDelete(Request $request)
    {
        try {
            $ids = $request->ids;
            if ($request->ajax()) {
                Variation::destroy($ids);
    
                return response()->json(['message' => __('Thành công')]);
            }
        } catch (\Exception $ex) {
            report($ex);
            return response()->json([
                'error' => true,
                'message' => __('Admin::business-office.delete.failure')
            ]);
        }
    }
    

}
