<?php

return [
    'name' => 'Name',
    'type' => 'Type',
    'values' => 'Values',
    'values.*.label' => 'Label',
    'values.*.color' => 'Color',
    'values.*.image' => 'Image',
];
