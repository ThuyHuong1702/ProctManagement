<?php

return [
    'variations' => 'Variations',
];
